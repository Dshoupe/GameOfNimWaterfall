﻿using GameOfNimWaterfall.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameOfNimWaterfall
{
    public class Driver
    {
        public static void Main(string[] args)
        {
            Game.GameSetup();
        }
    }
}