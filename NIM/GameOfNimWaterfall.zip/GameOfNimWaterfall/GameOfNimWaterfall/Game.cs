﻿using CSC160_ConsoleMenu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameOfNimWaterfall.Models
{
    public static class Game
    {
        public static Heap[] heaps;
        private static Player[] players = new Player[2];

        public static void GameSetup()
        {
            bool exitGame = false;

            do
            {
                int mainSelection = CIO.PromptForMenuSelection(new String[] { "Start Game", "View Instructions" }, true);

                switch (mainSelection)
                {
                    case 1:
                        bool exitMode = false;
                        do
                        {
                            int gameMode = CIO.PromptForMenuSelection(new String[] { "PVC", "PVP", "Instructions", "Go Back" }, false);

                            switch (gameMode)
                            {
                                case 1: 
                                case 2:
                                    int[] heapNums = new int[] { 0 };

                                    bool exitDifficulty = false;
                                    do
                                    {
                                        int difficultySelect = CIO.PromptForMenuSelection(new String[] { "Easy", "Medium", "Hard", "Instructions", "Go Back" }, true);

                                        heapNums = new int[] { 0 };
                                        switch (difficultySelect)
                                        {
                                            case 1:
                                                heapNums = new int[] { 3, 3 };
                                                exitDifficulty = true;
                                                break;
                                            case 2:
                                                heapNums = new int[] { 2, 5, 7 };
                                                exitDifficulty = true;
                                                break;
                                            case 3:
                                                heapNums = new int[] { 2, 3, 8, 9 };
                                                exitDifficulty = true;
                                                break;
                                            case 4:
                                                PrintInstructions();
                                                break;
                                            case 5:
                                                //Go back 1 layer
                                                break;
                                            case 0:
                                                exitMode = true;
                                                exitDifficulty = true;
                                                break;
                                        }
                                        CreateHeaps(heapNums);
                                    } while (!exitDifficulty);

                                    //Play Game
                                    if (heapNums[0] != 0)
                                    {
                                        CreateHeaps(heapNums);
                                        CreatePlayers(gameMode);
                                        PlayGame();
                                    }
                                    else
                                    {
                                        exitMode = true;
                                    }

                                    break;
                                case 3:
                                    PrintInstructions();
                                    break;
                                case 4:
                                    exitMode = true;
                                    break;
                            }
                        } while (!exitMode);
                        break;
                    case 2:
                        PrintInstructions();
                        break;
                    case 0:
                        exitGame = true;
                        break;
                }
            } while (!exitGame);
        }

        public static int GetRandom(int max)
        {
            Random rand = new Random();
            return rand.Next(1, max - 1);
        }

        private static void CreateHeaps(int[] heaps)
        {

        }

        private static void CreatePlayers(int count)
        {

        }

        private static void PlayGame()
        {

        }

        public static void PrintInstructions()
        {
            Console.WriteLine("");
        }
    }
}