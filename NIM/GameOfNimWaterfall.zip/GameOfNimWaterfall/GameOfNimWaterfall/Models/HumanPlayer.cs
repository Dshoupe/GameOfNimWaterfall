﻿using CSC160_ConsoleMenu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameOfNimWaterfall.Models
{
    public class HumanPlayer : Player
    {
        public override int[] TakeTurn()
        {
            int heap = 0;
            int tileAmount = 0;
            bool isDone = false;
            do
            {
                int userChoice = CIO.PromptForMenuSelection(new string[] { "Take Turn", "Instructions" }, true);
                switch (userChoice)
                {
                    case 1:
                        do
                        {
                            heap = CIO.PromptForInt($"Enter a heap (1 - {Game.heaps.Count()}): ", 1, Game.heaps.Count())-1;
                        } while (Game.heaps[heap].Tiles == 0);

                        tileAmount = CIO.PromptForInt($"How many tiles would you like to take (1 - {Game.heaps[heap].Tiles}): ", 1, Game.heaps[heap].Tiles);

                        isDone = true;
                        break;
                    case 2:
                        Game.PrintInstructions();
                        break;
                    case 0:
                        isDone = true;
                        break;
                }
            } while (!isDone);

            return new int[] { heap, tileAmount };
        }
    }
}