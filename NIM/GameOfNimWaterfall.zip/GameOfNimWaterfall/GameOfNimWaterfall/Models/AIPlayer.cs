﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameOfNimWaterfall.Models
{
    public class AIPlayer : Player
    {
        public AIPlayer(){
            this.Name = "Computer";
        }    

        public override int[] TakeTurn()
        {
            int heap = 0;
            do
            {
                heap = Game.GetRandom(Game.heaps.Count());
            } while (Game.heaps[heap].Tiles == 0);

            int tileAmount = Game.GetRandom(Game.heaps[heap].Tiles);

            return new int[] { heap, tileAmount };
        }
    }
}